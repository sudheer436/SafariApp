/**
 * The BookingRestController program implements an application that
 * This is the class to handle booking related rest end points
 *
 * @author  Sudheeraprasad
 * @version 1.0
 * @since   23/09/2021 
 * 
 * 
 */

package com.spring.boot.controller;

import java.util.HashMap;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.spring.boot.entity.Booking;
import com.spring.boot.entity.User;
import com.spring.boot.repo.BookingRepo;
import io.swagger.annotations.ApiOperation;

@RestController
public class BookingRestController {

	private static final Logger logger = LogManager.getLogger(BookingRestController.class);

	@Autowired
	BookingRepo bookingRepo;

	/**
	 * to access property file value dynamicaly
	 */

	@Value("${spring.message}")
	private  String message;


	/**
	 * This method is used to add to do user safari booking 
	 * 
	 */
	@ApiOperation(value = "booking  in the System ", response = Booking.class, tags = "booking")
	@PostMapping(value = "/booking")
	public String booking(@RequestBody Booking booking) {

		logger.info("calling booking method  to book the safari");

		bookingRepo.save(booking);
		return "Your booking is Success";
	}

	/**
	 * This method is used to add to see pricing for safari app 
	 * 
	 */
	@ApiOperation(value = "get priceList in the System ", response = Booking.class, tags = "getPriceList")
	@GetMapping(value = "/getPriceList")
	public Map<String, Integer> getPriceList() {

		logger.info("calling priceList method  to see the price list");

		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("adult",1000);
		map.put("kid",500);
		map.put("student",350);
		map.put("foreigner",2000);

		return map;
	}

}

