/**
 * The UserRestController program implements an application that
 * This is the class to handle user related rest end points
 *
 * @author  Sudheeraprasad
 * @version 1.0
 * @since   23/09/2021 
 * 
 * 
 */

package com.spring.boot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.spring.boot.entity.User;
import com.spring.boot.repo.UserRepo;
import com.spring.boot.service.UserService;
import com.spring.boot.util.UtilitMethods;
import java.util.List;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


@RestController
public class UserRestController {

	private static final Logger logger = LogManager.getLogger(UserRestController.class);


	@Autowired
	UserService userService;

	@Autowired
	UserRepo userRepo;

	/**
	 * to access property file value dynamicaly
	 */
	@Value("${spring.message}")
	private  String message;


	@ApiResponses(value = { 
			@ApiResponse(code = 200, message = "Suceess|OK"),
			@ApiResponse(code = 401, message = "not authorized!"), 
			@ApiResponse(code = 403, message = "forbidden!!!"),
			@ApiResponse(code = 404, message = "not found!!!") })


	/**
	 * This method is used to add to some prerequisit user data in db for safari app 
	 * Its a GET method 
	 * input @param empty
	 * 
	 */
	@ApiOperation(value = "get some user data in the System ", response = User.class, tags = "addSampleUserData")
	@GetMapping(value = "/addSampleUserData")
	public String addSampleUserData() {

		logger.info("calling getData method  to get sample user values");

		User user1 = new User(101,"sham","china",123);
		userRepo.save(user1);

		return "users added successfully";

	}


	/**
	 * This method is used to add, If user is new,Registring the user for safari app 
	 * Its a POST method 
	 * input @param User object
	 * 
	 */
	@ApiOperation(value = "add user in the System ", response = User.class, tags = "registerUser")
	@PostMapping(value = "/register")
	public User addEmployee(@RequestBody User user) {

		logger.info("calling register method  to register user");

		//User user = new User(id, name, country);
		return userRepo.save(user);
		//return "user added successfully";
	}

	/**
	 * This method is used user to login into the safari app 
	 * Its a POST method 
	 * input @param String as name 
	 * input @param int as password
	 * 
	 */
	@ApiOperation(value = "login into the System ", response = User.class, tags = "login")
	@PostMapping(value = "/login")
	public String login(@RequestParam("name") String name, @RequestParam("password") int password) {

		logger.info("calling login method for the user");
		User user=userRepo.findOne(password);
		if(user!=null)
		{
			return "login success";
		}
		else
		{
			return "invalid user";
		}
	}

	/**
	 * This method is used to get user by id for  safari app 
	 * Its a POST method 
	 * input @param int as password
	 * 
	 */
	@ApiOperation(value = "get user by id in the System ", response = User.class, tags = "getUserById")
	@PostMapping(value = "/getUserById")
	public User getUserById(@RequestParam("id") int id) {

		User user=userRepo.findOne(id);
		return user;

	}

	/**
	 * This method is used user to get all users of the safari app 
	 * Its a GET method 
	 * input @param empty
	 * 
	 * 
	 */
	@ApiOperation(value = "get all user in the System ", response = User.class, tags = "getAllUser")
	@GetMapping(value = "/getAllUser")
	public List<User> getAll() {

		logger.info("calling getAllUser method  to see all users list");

		List<User> result=(List<User>) userRepo.findAll();

		/**
		 * writng json value into file
		 */
		UtilitMethods util=new UtilitMethods();
		util.writeJsonIntoFiles(result, message);

		return result;
	}

}