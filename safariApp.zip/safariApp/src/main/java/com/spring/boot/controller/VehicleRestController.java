/**
 * The VehicleRestController program implements an application that
 * This is the class to handle vehicle related rest end points
 *
 * @author  Sudheeraprasad
 * @version 1.0
 * @since   23/09/2021 
 * 
 * 
 */

package com.spring.boot.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.spring.boot.entity.User;
import com.spring.boot.entity.Vehicles;
import com.spring.boot.repo.VehicleRepo;
import com.spring.boot.util.UtilitMethods;
import io.swagger.annotations.ApiOperation;

@RestController
public class VehicleRestController {

	private static final Logger logger = LogManager.getLogger(VehicleRestController.class);

	@Autowired
	VehicleRepo vehicleRepo;

	/**
	 * to access property file value dynamicaly
	 */
	@Value("${spring.message}")
	private  String message;

	/**
	 * This method is used to get some prerequisit data in the database
	 * Its a GET method 
	 * input @param empty
	 * 
	 */
	@GetMapping(value = "/getSampleVehicleData")
	public String getSampleVehicleData() {

		logger.info("calling getSampleVehicleData method  to get sample vehcile list");

		Vehicles vehicles1= new Vehicles();
		vehicles1.setId(101);
		vehicles1.setRegNum("KA 01 T111");
		vehicles1.setType("jeep");

		Vehicles vehicles2= new Vehicles();
		vehicles2.setId(102);
		vehicles2.setRegNum("KA 01 T222");
		vehicles2.setType("Gypsy");

		Vehicles vehicles3= new Vehicles();
		vehicles3.setId(103);
		vehicles3.setRegNum("KA 01 T333");
		vehicles3.setType("bus");

		vehicleRepo.save(vehicles1);
		vehicleRepo.save(vehicles2);
		vehicleRepo.save(vehicles3);

		return "Vehicles added successfully";

	}

	/**
	 * This method is used to add, If vehicle is new, adding the vehicle for safari app 
	 * Its a POST method 
	 * input @param Vehicle object
	 * 
	 */
	@ApiOperation(value = "add user in the System ", response = Vehicles.class, tags = "addVehicle")
	@PostMapping(value = "/addVehicle")
	public String addVehicle(@RequestBody Vehicles vehicles) {

		logger.info("calling addVehicle method  to add new vehicles into application");

		vehicleRepo.save(vehicles);
		return "vehicle added successfully";
	}

	/**
	 * This method is used to get all vehicles for safari app 
	 * Its a GET method 
	 * input @param empty
	 * 
	 */
	@ApiOperation(value = "get all user in the System ", response = Vehicles.class, tags = "getAllVehicles")
	@GetMapping(value = "/getAllVehicles")
	public List<Vehicles> getAllVehicles() {

		logger.info("calling getVehicles method  to see all vehicles list");

		List<Vehicles> result=(List<Vehicles>) vehicleRepo.findAll();
		/**
		 * writng json value into file
		 */
		UtilitMethods util=new UtilitMethods();
		util.writeJsonVehicleValuesIntoFiles(result, message);

		return result;
	}

}
