/**
 * The Booking program implements an application that
 * This is the entity class
 *
 * @author  Sudheeraprasad
 * @version 1.0
 * @since   23/09/2021 
 * 
 * 
 */

package com.spring.boot.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "booking")	
public class Booking {


	@Id
	private int id;

	@Column(name="name")
	private String name;

	@Column(name="amount")
	private int amount;

	/**
	 * setters and getters for id
	 * @return 
	 */
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	/**
	 * setters and getters for name
	 * @return 
	 */
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * setters and getters for amount
	 * @return 
	 */
	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	/**
	 * toString method is used to represent object as string
	 *  
	 */
	@Override
	public String toString() {
		return "Booking [id=" + id + ", name=" + name + ", amount=" + amount + "]";
	}

}


