/**
 * The User program implements an application that
 * This is the entity class
 *
 * @author  Sudheeraprasad
 * @version 1.0
 * @since   23/09/2021 
 * 
 * 
 */
package com.spring.boot.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table (name = "user")
public class User {

	@Id
	private int id;

	@Column(name="name")
	private String name;

	@Column(name="country")
	private String country;

	@Column(name="password")
	private int password;

	/**
	 * default constructor
	 * 
	 */
	public User() {}

	/**
	 * parameterised constructor
	 * 
	 */
	public User(int id, String name, String country, int password) {
		super();
		this.id = id;
		this.name = name;
		this.country = country;
		this.password = password;
	}

	/**
	 * setters and getters for id
	 * @return 
	 */
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	/**
	 * setters and getters for name
	 * @return 
	 */
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * setters and getters for country
	 * @return 
	 */
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * setters and getters for password
	 * @return 
	 */
	public int getPassword() {
		return password;
	}

	public void setPassword(int password) {
		this.password = password;
	}

	/**
	 * toString method is used to represent object as string
	 *  
	 */
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", country=" + country + ", password=" + password + "]";
	}

}
