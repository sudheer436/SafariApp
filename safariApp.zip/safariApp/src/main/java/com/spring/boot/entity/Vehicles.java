/**
 * The Vehicles program implements an application that
 * This is the entity class
 *
 * @author  Sudheeraprasad
 * @version 1.0
 * @since   23/09/2021 
 * 
 * 
 */
package com.spring.boot.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table (name = "vehicles")
public class Vehicles {

	@Id
	private int id;

	@Column(name="regNum")
	private String regNum;

	@Column(name="type")
	private String type;

	/**
	 * setters and getters for id
	 * @return 
	 */
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	/**
	 * setters and getters for reg num
	 * @return 
	 */
	public String getRegNum() {
		return regNum;
	}

	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}

	public String getType() {
		return type;
	}

	/**
	 * setters and getters for type
	 * @return 
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * toString method is used to represent object as string
	 *  
	 */
	@Override
	public String toString() {
		return "Vehicles [id=" + id + ", regNum=" + regNum + ", type=" + type + "]";
	}




}


