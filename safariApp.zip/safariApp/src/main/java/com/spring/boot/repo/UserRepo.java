/**
* The UserRepo program implements an application that
* This is the dao layer for UserRepo
*
* @author  Sudheeraprasad
* @version 1.0
* @since   23/09/2021 
* 
* 
*/
package com.spring.boot.repo;

import org.springframework.data.repository.CrudRepository;
import com.spring.boot.entity.User;

public interface UserRepo extends CrudRepository<User, Integer> {
	
}
