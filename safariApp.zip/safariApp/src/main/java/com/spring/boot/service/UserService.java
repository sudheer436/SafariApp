/**
 * The UserService program implements an application that
 * This is the service layer for UserService
 *
 * @author  Sudheeraprasad
 * @version 1.0
 * @since   23/09/2021 
 * 
 * 
 */
package com.spring.boot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.boot.entity.User;
import com.spring.boot.repo.UserRepo;

@Service
public class UserService {

	@Autowired
	UserRepo userRepo;


	/**
	 * This is the service layer for UserService for save method
	 * 
	 */
	public void saveOrUpdate(User user)
	{
		userRepo.save(user);
	}

}
