/**
 * The UtilitMethods program implements an application that
 * This is the util class for all common and reuse methods
 *
 * @author  Sudheeraprasad
 * @version 1.0
 * @since   23/09/2021 
 * 
 * 
 */

package com.spring.boot.util;

import java.io.FileWriter;
import java.util.List;
import com.spring.boot.entity.User;
import com.spring.boot.entity.Vehicles;

public class UtilitMethods {

	/**
	 * Use Files class from Java 1.7 to write files, internally uses OutputStream
	 * @param data
	 */
	public  void writeUsingFiles(String data, String message) {

		try {
			FileWriter fout=new FileWriter(message);
			fout.write(data);
			fout.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	/**
	 * Use Files class from Java 1.7 to write files, internally uses OutputStream
	 * @param data
	 */
	public  void writeJsonIntoFiles(List<User> result, String message) {

		try {
			FileWriter fout=new FileWriter(message);
			fout.write(((Object) result).toString());
			fout.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Use Files class from Java 1.7 to write files, internally uses OutputStream
	 * @param data
	 */
	public  void writeJsonVehicleValuesIntoFiles(List<Vehicles> result, String message) {

		try {
			FileWriter fout=new FileWriter(message);
			fout.write(((Object) result).toString());
			fout.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
