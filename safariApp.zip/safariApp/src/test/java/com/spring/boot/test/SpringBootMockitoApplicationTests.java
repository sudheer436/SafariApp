/*package com.spring.boot.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.spring.boot.entity.User;
import com.spring.boot.repo.BookingRepo;
import com.spring.boot.repo.UserRepo;
import com.spring.boot.repo.VehicleRepo;
import com.spring.boot.service.UserService;


@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringBootMockitoApplicationTests {
	
	
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	VehicleRepo vehicleRepo;
	
	@Autowired
	BookingRepo bookingRepo;

	@Test
	public void getUsersTest() {
		when(userRepo.findAll()).thenReturn(Stream
				.of(new User(101, "Danile","USA",123), new User(102, "sam","UK",123)).collect(Collectors.toList()));
		assertEquals(2, ((List<User>) userRepo.findAll()).size());
	}

	@Test
	public void getUserbyIdTest() {
		int id = 101;
		when(userRepo.findOne(id))
				.thenReturn((User) Stream.of(Stream
						.of(new User(101, "Danile","USA",123)).collect(Collectors.toList())));
		assertEquals(1, userRepo.findOne(id));
	}

	@Test
	public void saveUserTest() {
		User user = new User(101, "Danile","USA",123);
		when(userRepo.save(user)).thenReturn((User) Stream
				.of(new User(101, "Danile","USA",123)).collect(Collectors.toList()));
		assertEquals(user, user);
	}
}*/